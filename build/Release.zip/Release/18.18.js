webpackJsonp([18],{

/***/ 583:
/***/ (function(module, exports) {

	"use strict";

	module.exports = { a: 2 };

/***/ })

});