webpackJsonp([20],{

/***/ 649:
/***/ (function(module, exports) {

	"use strict";

	module.exports = { a: 2 };

/***/ })

});