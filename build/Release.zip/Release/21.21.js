webpackJsonp([21],{

/***/ 1294:
/***/ (function(module, exports) {

	"use strict";

	module.exports = { a: 2 };

/***/ })

});