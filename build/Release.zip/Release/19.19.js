webpackJsonp([19],{

/***/ 619:
/***/ (function(module, exports) {

	"use strict";

	module.exports = { a: 2 };

/***/ })

});