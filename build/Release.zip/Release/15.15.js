webpackJsonp([15],{

/***/ 520:
/***/ (function(module, exports) {

	"use strict";

	module.exports = { a: 2 };

/***/ })

});
//# sourceMappingURL=15.15.js.map