webpackJsonp([22],{

/***/ 1371:
/***/ (function(module, exports) {

	"use strict";

	module.exports = { a: 2 };

/***/ })

});