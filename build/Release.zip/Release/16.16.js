webpackJsonp([16],{

/***/ 536:
/***/ (function(module, exports) {

	"use strict";

	module.exports = { a: 2 };

/***/ })

});